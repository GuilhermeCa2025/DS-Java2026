package exercício2;

import java.util.Scanner;

class Conta extends Exception {

    public Conta(double saldo, double saque) {
        super("Saldo insuficiente. Saldo disponível: R$ "
                + String.format("%.2f", saldo)
                + ". Valor solicitado: R$ "
                + String.format("%.2f", saque));
    }
}
public class Exercício2 {

    public static void main(String[] args) {
        
         Scanner sc = new Scanner(System.in);
         
         try{
             System.out.println("Saldo Disponível: R$");
             double saldo = sc.nextDouble();
             
             System.out.println("Valor do saque: R$");
             double saque = sc.nextDouble();
             
             if (saque <= 0) {
                 throw new IllegalArgumentException(" O valor do saque deve ser maior que zero seu jumento!");
             }
             if (saque > saldo) {
                 throw new Conta(saldo, saque);
             }
             System.out.println("Parabèns!! Agora você tem dinheiro na conta seu pobre");
         }catch (Conta e){
             System.out.println("Erro: " + e.getMessage());
             } catch (IllegalArgumentException e) {

            System.out.println("Erro: " + e.getMessage());

        } finally {

            System.out.println("Operação finalizada.");
            sc.close();
        }
    }
}
    

