
package exercício2;

public class Conta{
    double saldo = 0 ;
    
}
