package exceção;
import java.util.Scanner;

public class Exceção {

    public static void main(String[] args) {
        int idade = 0;
        
          Scanner sc = new Scanner(System.in);
          try{
            System.out.println("Digite sua idade: ");
          idade = sc.nextInt();
          
              if ( idade > 120){
                  throw new Minha("Como que você tá vivo? ");
          }
              System.out.println("Você é um ser humano (ainda...)");
          }catch(Minha e){
              System.out.println(e.getMessage());
          } 
              sc.close();
                       
    }
    
}
