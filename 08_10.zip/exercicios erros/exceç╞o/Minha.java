/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceção;

public class Minha extends Exception{
    public Minha (String mensagem){
        super (mensagem);
        
    }
   }
