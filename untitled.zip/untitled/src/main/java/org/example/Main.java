package org.example;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main { public static void main(String[] args) {
    // Configuração dos parâmetros de autenticação
    String server = "localhost";
    String port = "3306";
    String database = "malk";
    String user = "root";
    String passwd = "";
    String url = "jdbc:mysql://" + server + ":" + port + "/" + database;

    Connection conexao = null;
    PreparedStatement stmt = null;
    String instruçãoSQL = "INSERT INTO Aluno(Matrícula,nome,email,idade)" +
            "Values (?,?,?,?)";


    try {
        System.out.println("Conectando ao Banco de Dados...");
        conexao = DriverManager.getConnection(url, user, passwd);
        System.out.println("Conexão efetuada com sucesso!");
        stmt = conexao.prepareStatement(instruçãoSQL);
        stmt.setInt(1,13);
        stmt.setString(2,"Guilherme");
        stmt.setString(3,"guizumba26@gmail.com");
        stmt.setInt(4,17);
        stmt.execute();
        System.out.println("Dados inseridos com sucesso");
        stmt.close();
        conexao.close();

    } catch (SQLException e) {
        System.out.println("Erro ao conectar ao banco de dados.");
        e.printStackTrace();
    }


} }